How to run Orphanage Management System using PHP and MySQL

1. Download the zip file

2. Extract the file and copy oms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name omsdb

6. Import omsdb.sql file(given inside the zip package in the SQL file folder)

7. Run the script http://localhost/oms

Credential for Admin panel :

Username: admin
Password: Test@123

Credential for user panel :

Username: rahul12
Password: Test@123

or Register a new user.
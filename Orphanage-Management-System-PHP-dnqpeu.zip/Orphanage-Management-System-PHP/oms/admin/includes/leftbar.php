
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                  

                       <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i> Child<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="add-child.php">Add</a>
                                </li>
                                <li>
                                    <a href="manage-child.php">Manage</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

    <li>
                            <a href="manage-users.php"><i class="fa fa-users"></i> Manage Users</a>
                        </li>
                      


                        <li>
                            <a href="#"><i class="fa fa-book"></i> Adoption Request<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                 <li>
                                    <a href="new-adoption-request.php">New Request</a>
                                </li>
                                <li>
                                    <a href="all-adoption-request.php">All Request</a>
                                </li>
                                <li>
                                    <a href="accepted-adoption-request.php">Accepted Request</a>
                                </li>
                                <li>
                                    <a href="rejected-adoption-request.php">Rejected Request</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
   <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i> News<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="add-news.php">Add </a>
                                </li>
                                <li>
                                    <a href="manage-news.php">Manage </a>
                                </li>
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i> Report<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="between-dates-report.php">B/W Date Report </a>
                                </li>
                                <li>
                                    <a href="search-report.php">Search Report </a>
                                </li>
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i> Website Setting<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="about-us.php">About us </a>
                                </li>
                                <li>
                                    <a href="website-setting.php">General Settings</a>
                                </li>
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
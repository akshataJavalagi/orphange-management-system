  <div class="col-md-3 col-md-offset-1 col-sm-5 col-xs-12">
                           <div class="total-widget">
                               <div class="single-widget catagory-widget">
                                  <h3 class="aside-title uppercase">My Account</h3>
                                   <ul>
                                       <li><a href="profile.php">My Profile</a></li>
                                       <li><a href="change-password.php">Change Password</a></li>
                                       <li><a href="my-bookings.php">My Booking</a></li>
                                       <li><a href="logout.php">Logout</a></li>
                                   </ul>
                               </div>
                            
                       </div>
                   </div>